<?php 
echo("kupa");
$NazwaSerwera = "localhost"; 
$Uzytkownik = "root"; 
$Haslo = "root"; 
$BazaDanych = "uzytkownicy"; 
$conn = mysqli_connect($NazwaSerwera, $Uzytkownik);
?>